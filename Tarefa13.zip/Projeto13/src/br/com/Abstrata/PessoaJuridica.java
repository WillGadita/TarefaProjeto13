package br.com.Abstrata;

public class PessoaJuridica extends Pessoa{

	private Integer cnpj;

	public Integer getCnpj() {
		return cnpj;
	}

	public void setCnpj(Integer cnpj) {
		this.cnpj = cnpj;
	}
	
	
	
}

