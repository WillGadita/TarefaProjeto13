package br.com.Abstrata;

public class PessoaFisica extends Pessoa {

	private Integer cpf;

	public Integer getCpf() {
		return cpf;
	}

	public void setCpf(Integer cpf) {
		this.cpf = cpf;
	}
	
	
	
}
