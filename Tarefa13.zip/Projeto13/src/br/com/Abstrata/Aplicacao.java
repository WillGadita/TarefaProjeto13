package br.com.Abstrata;

public class Aplicacao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
    PessoaJuridica pessoa = new PessoaJuridica();
    pessoa.setNome("Willian Reis");
    pessoa.setCnpj(1235);
    impressao(pessoa);
    
    PessoaFisica cliente = new PessoaFisica();
    cliente.setNome("Willian Reis");
    cliente.setCpf(1527);
    imprimir(cliente);
    
	
		

	}

	private static void impressao(PessoaJuridica pessoa) {
		System.out.println("Nome do Cliente: " + pessoa.getNome());
		System.out.println("CNPJ do Cliente: " + pessoa.getCnpj());
		
		System.out.println("+++++++++++ // +++++++++++ // +++++++++++ // ++++++++");
		
	}

	private static void imprimir(PessoaFisica cliente) {
		System.out.println("Nome do Cliente: " + cliente.getNome());
		System.out.println("CPF do Cliente: " + cliente.getCpf());
		
	}

}
